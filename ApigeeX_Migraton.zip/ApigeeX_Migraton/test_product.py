import sys
import zipfile
import os
from os import path
import shutil
import zipfile as zp
import re
import pyutil
import json
import requests
from pathlib import Path
from datetime import date
from resources import MigrateResources
from datetime import datetime, timezone
import csv


current_path="date_edge_test"
folder_name = "date_edge_test"
app_path=folder_name+"\\apps"
#dev_path=folder_name+"\\developers"
app_names_arr = os.listdir(app_path)
number_of_apps = len(app_names_arr)
print("APPs Name --> "+str(app_names_arr))
arr_filename = os.listdir(app_path)

product_path=current_path+"\\products"
arr_product_name=[];
arr_products=os.listdir(product_path)
for prod in arr_products:
    arr_product_name.append(prod)
    print(prod)
print(arr_product_name)
arr_product_name=str(arr_product_name)
arr_product_name=arr_product_name.replace("[","")
arr_product_name=arr_product_name.replace("]","")
arr_product_name=arr_product_name.replace("'","")
print("Products Name --> "+arr_product_name)


for file in arr_filename:
    line_as_string=''
    f_path=app_path+"\\"+file
    file2=open(f_path, 'r')
    key_data={}
    lines = file2.readlines()
    for line in lines:
        line_as_string=line_as_string+line        
    file2.close()
    print("Line As String "+line_as_string)
    matches_app_name = re.findall('value"\s*\:\s*"(.*?)"', line_as_string, re.DOTALL)
    print("APP Name -->" +str(matches_app_name))
    
    matches_consumerKey = re.findall('consumerKey"\s*\:\s*"(.*?)"', line_as_string, re.DOTALL)
    print("COnsumer Key -->" +str(matches_consumerKey))

    matches_consumerSecret = re.findall('consumerSecret"\s*\:\s*"(.*?)"', line_as_string, re.DOTALL)
    print("Consumer Secret --> "+ str(matches_consumerSecret))

    matches_expiresAt = re.findall('expiresAt"\s*\:(.*?),', line_as_string, re.DOTALL)
    print("Expires at --> "+ str(matches_expiresAt))

    matches_status = re.findall('status"\s*\:\s*"(.*?)"', line_as_string, re.DOTALL)
    print("STATUS --> "+ str(matches_status))

    matches_expiresInSeconds = re.findall('status"\s*\:\s*"(.*?)"', line_as_string, re.DOTALL)
    print("Expires at--> " + str(matches_expiresInSeconds))
    
    f_path=app_path+"\\"+file
    file2=open(f_path, 'r')
    data = json.load(file2)
    app_name = data['name']
    string_product_name = str(data['credentials'][0]['apiProducts'])
    array_product_name = string_product_name.split('apiproduct')
    product_names=''
    for product_name in array_product_name:
        product_name = re.sub(r'status','',product_name)
        product_name = re.sub(r'approved','',product_name)
        product_name = re.sub(r'pending','',product_name)
        product_name = re.sub(r'[\{\}\[\]\'\,\:]','',product_name)
        product_name = re.sub(r'\s+', ' ',product_name)
        product_name = product_name.strip()
        product_name = "="+product_name+",="
        product_names = product_names+product_name
        
    product_names = re.sub(r'==','',product_names)
    product_names = re.sub(r'\,\,',',',product_names)
    product_names = re.sub(r'\,\,',',',product_names)
    product_names = re.sub(r'\=\,','',product_names)
    product_names = re.sub(r'\,\=','',product_names)                
    #product_names = '{ "name":"'+app_name+',apiProducts" :['+product_names+'] }'
    product_names = '{ "apiProducts" :['+product_names+'] }'

    product_names = re.sub(r'\[','["',product_names)
    product_names = re.sub(r'\]','"]',product_names)
    product_names = re.sub(r'\,','","',product_names)
    print("Product Names --> " + str(product_names))
    json_product_names = json.loads(product_names)




# for filename in app_names_arr:
#     f_path=app_path+"\\"+filename
#     file2=open(f_path, 'r')
#     data = json.load(file2)
#     app_name = data['name']
#     string_product_name = str(data['credentials'][0]['apiProducts'])
#     array_product_name = string_product_name.split('apiproduct')
#     product_names=''
#     for product_name in array_product_name:
#         product_name = re.sub(r'status','',product_name)
#         product_name = re.sub(r'approved','',product_name)
#         product_name = re.sub(r'pending','',product_name)
#         product_name = re.sub(r'[\{\}\[\]\'\,\:]','',product_name)
#         product_name = re.sub(r'\s+', ' ',product_name)
#         product_name = product_name.strip()
#         product_name = "="+product_name+",="
#         product_names = product_names+product_name
        
#     product_names = re.sub(r'==','',product_names)
#     product_names = re.sub(r'\,\,',',',product_names)
#     product_names = re.sub(r'\,\,',',',product_names)
#     product_names = re.sub(r'\=\,','',product_names)
#     product_names = re.sub(r'\,\=','',product_names)                
#     product_names = '{ "name":"'+app_name+',apiProducts" :['+product_names+'] }'
#     product_names = re.sub(r'\[','["',product_names)
#     product_names = re.sub(r'\]','"]',product_names)
#     product_names = re.sub(r'\,','","',product_names)
#     json_product_names = json.loads(product_names)
#     print(json_product_names)