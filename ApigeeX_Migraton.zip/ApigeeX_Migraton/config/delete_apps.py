import requests

for i in range(0,4001):
  url = "https://api.enterprise.apigee.com/v1/organizations/nitinmahavir2021-eval/developers/sangem007@gmail.com/apps/Test APP "+str(i)

  payload = {}
  headers = {
    'Authorization': 'Basic bml0aW5tYWhhdmlyMjAyMUBnbWFpbC5jb206SmFkaGF2MTkh'
  }

  response = requests.request("DELETE", url, headers=headers, data=payload)

  print(response.text)
