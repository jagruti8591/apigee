import json
import requests


class Upload:
	"""This class uploads the zip to hybrid"""
	def __init__(self):
		super(Upload, self).__init__()
		
	
	def upload_to_hybrid(path,filename,token,org,resource_type,resourceId,log_file):
		print("--------------------------------------------------------------------------------------------")
		print("|                     Starting to upload proxy on hybrid                                   |")
		print("--------------------------------------------------------------------------------------------")


		#resourceId="apiProxyId"
		url = "https://apigee.googleapis.com/v1/organizations/"+org+"/"+resource_type+"?action=import&name="+filename+"&"+resourceId+" ="+filename
		payload={}
		files=[('file',(filename+'_new.zip',open(path+"\\"+filename+"\\"+filename+"_new.zip",'rb'),'application/zip'))]
		headers = {'Authorization': 'Bearer '+token}
		response = requests.request("POST", url, headers=headers, data=payload, files=files)
		status_code = response.status_code
		successful_upload = []
		if status_code ==200:
			successful_upload.append(filename)
			print("--------------------------------------------------------------------------------------------")
			print("|                      PROXY WAS UPLOADED SUCCESSFULLY                                     |")
			print("--------------------------------------------------------------------------------------------")
			print(successful_upload)
			with open(log_file, "a", encoding="utf-8") as f:					
				new_log="        PROXY UPLOADED  "+filename+"  "+str(status_code)+"\n"
				f.write(new_log)
			f.close()						
			#print(response.text)
		if status_code == 401:
			print("--------------------------------------------------------------------------------------------")
			print("|                       !!! ERROR UNAUTHORIZED !!!                                         |")
			print("--------------------------------------------------------------------------------------------")
			with open(log_file, "a", encoding="utf-8") as f:					
				new_log="        Upload ERROR Invalid Token Used "+str(status_code)+"\n"
				f.write(new_log)
			f.close()
			print(response.text)
			#exit()
		if status_code == 400:
			print("--------------------------------------------------------------------------------------------")
			print("   					  !!! ERROR The Zip Bundle Contains Error !!!                         |")
			print("--------------------------------------------------------------------------------------------")

			print(response.text)
			with open(log_file, "a", encoding="utf-8") as f:					
				new_log="        Upload ERROR Zip file has errors "+str(status_code)+"\n"
				f.write(new_log)
			f.close()			
			#exit()


class Deploy:
	"""docstring for ClassName"""
	def __init__(self):
		super(Deploy, self).__init__()

	def deploy_to_hybrid(evn,filename,token,org,resource_type,log_file):
		#resource_counter=resource_counter+1
		#print("<===================== Total Deployed Counter ==========================>" +str(resource_counter))
		print("--------------------------------------------------------------------------------------------")
		print("|                     Starting to Deploy proxy on hybrid                                   |")
		print("--------------------------------------------------------------------------------------------")
		url = "https://apigee.googleapis.com/v1/organizations/"+org+"/environments/"+evn+"/"+resource_type+"/"+filename+"/revisions/1/deployments"
		payload={}
		headers = {'Content-Type': 'application/json','Authorization': 'Bearer '+token}
		response = requests.request("POST", url, headers=headers, data=payload)
		status_code = response.status_code
		successful_deploy = []
		if status_code ==200:
			successful_deploy.append(filename)
			print("--------------------------------------------------------------------------------------------")
			print("|                      PROXY WAS DEPLOYED SUCCESSFULLY                                     |")
			print("--------------------------------------------------------------------------------------------")
			print(successful_deploy)
			with open(log_file, "a", encoding="utf-8") as f:					
				new_log="        PROXY DEPLOYED   "+filename+"  "+str(status_code)+"\n"
				f.write(new_log)
			f.close()				
			#print(response.text)
		if status_code == 401:
			print("--------------------------------------------------------------------------------------------")
			print("|                       !!! ERROR UNAUTHORIZED !!!                                         |")
			print("--------------------------------------------------------------------------------------------")

			print(response.text)
			with open(log_file, "a", encoding="utf-8") as f:					
				new_log="        Deployment ERROR Invalid Token Used "+str(status_code)+"\n"
				f.write(new_log)
			f.close()
			print(response.text)			
			#exit()
		if status_code == 400:
			print("--------------------------------------------------------------------------------------------")
			print("   					  !!! ERROR The Zip Bundle Contains Error !!!                         |")
			print("--------------------------------------------------------------------------------------------")
			with open(log_file, "a", encoding="utf-8") as f:					
				new_log="        Deployment ERROR Zip file has errors "+str(status_code)+"\n"
				f.write(new_log)
			f.close()	
			print(response.text)
		



