import requests



for i in range(7000,7120):
  url = "https://api.enterprise.apigee.com/v1/organizations/nitinmahavir2021-eval/developers/ahamilton"+str(i)+"@example.com"

  payload = {}
  headers = {
    'Authorization': 'Basic bml0aW5tYWhhdmlyMjAyMUBnbWFpbC5jb206SmFkaGF2MTkh'
  }

  response = requests.request("DELETE", url, headers=headers, data=payload)

  print(response.text)